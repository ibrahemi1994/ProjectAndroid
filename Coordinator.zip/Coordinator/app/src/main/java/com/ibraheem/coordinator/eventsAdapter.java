
package com.ibraheem.coordinator;

import it.sephiroth.android.library.picasso.Picasso;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boro on 4/5/16.
 */

public class eventsAdapter extends ArrayAdapter<api.parser.Item> {


    LayoutInflater layoutInflater;
    ArrayList<api.parser.Item> myItems;
    public eventsAdapter(Context context, int resource, List<api.parser.Item> objects) {
        super(context, resource, objects);
        myItems= (ArrayList<api.parser.Item>) objects;
    }


    public void setLayoutInflater(LayoutInflater layoutInflater) {
        this.layoutInflater = layoutInflater;
    }




    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View itemView = convertView;
        if(itemView==null){
            itemView = layoutInflater.inflate(R.layout.item_view, parent, false);

        }
        // find the item to work with
       // Item currItem = myItems.get(position);
        api.parser.Item tmp =myItems.get(position);

        // FILL the view
        ImageView imageView = (ImageView)itemView.findViewById(R.id.item_icon);
        //  imageView.setImageResource(currItem.getId());
        Picasso.with(getContext()).load("https://collegeserver1.herokuapp.com/images/boro/"+ tmp.getImage()).resize(100,100).into(imageView);


        // Make:
        TextView makeText = (TextView) itemView.findViewById(R.id.item_name);
        makeText.setText(tmp.getName());

        // Make:
        TextView makeDes = (TextView) itemView.findViewById(R.id.item_desc);
        makeDes.setText(tmp.getDescription());

        return  itemView;

    }
}
