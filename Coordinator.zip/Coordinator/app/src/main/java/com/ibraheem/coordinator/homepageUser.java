package com.ibraheem.coordinator;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boro on 4/4/16.
 */
public class homepageUser extends MainActivity {

    Button user ;
    protected EditText ItemName;
    protected EditText ItemDescription;
    Context context;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        context=this;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepageuser);

        read();
    }

    private void read() {
        ListView list = (ListView) findViewById(R.id.userlistview);
        String username = getIntent().getStringExtra("user");
        api.Utils.getItemforuser(context, list, getLayoutInflater(), this, username);
    }


}
