package com.ibraheem.coordinator;

/**
 * Created by boro on 4/4/16.
 */
public class Item {
    private String name;
    private int id;
    private int bought;
    private String description;

    public Item(String name, int id, int bought , String description) {
        this.name = name;
        this.id = id;
        this.bought = bought;
        this.description=description;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public int getBought() {
        return bought;
    }

    public String getDescription() {
        return description;
    }
}
