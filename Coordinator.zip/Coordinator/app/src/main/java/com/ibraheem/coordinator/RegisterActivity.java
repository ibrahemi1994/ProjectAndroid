package com.ibraheem.coordinator;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import java.text.ParseException;

import api.Utils;

/**
 * Created by boro on 4/4/16.
 */
public class RegisterActivity extends MainActivity {

    protected EditText userName;
    protected EditText email;
    protected EditText password;
    protected Button mRegsiterButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


//    UserParse.saveInBackground();
        //initialze
        userName = (EditText) findViewById(R.id.userRegisterEditText);
        email = (EditText) findViewById(R.id.emailRegisterEditText);
        password = (EditText) findViewById(R.id.passwordRegisterEditText);
        mRegsiterButton = (Button) findViewById(R.id.btnRegister);
        final Context context = this;


        //listen to register button click
        mRegsiterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!validate()) {
                    onSignupFailed();
                    return;
                }
                else {

                    Utils.register(context, userName.getText().toString(), password.getText().toString(), email.getText().toString());
                }
            }
        });


    }

    public void onSignupFailed() {
        Toast.makeText(getBaseContext(), "Login failed", Toast.LENGTH_LONG).show();

        mRegsiterButton.setEnabled(true);
    }

    public boolean validate() {
        boolean valid = true;
        String name = userName.getText().toString();
        String emaill = email.getText().toString();
        String pass = password.getText().toString();
        if (name.isEmpty() || name.length() < 3) {
            userName.setError("at least 3 characters");
            valid = false;
        } else {
            userName.setError(null);
        }

        if (emaill.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(emaill).matches()) {
            email.setError("enter a valid email address");
            valid = false;
        } else {
            email.setError(null);
        }

        if (pass.isEmpty() || pass.length() < 4 || pass.length() > 10) {
            password.setError("between 4 and 10 alphanumeric characters");
            valid = false;
        } else {
            password.setError(null);
        }

        return valid;
    }
}



