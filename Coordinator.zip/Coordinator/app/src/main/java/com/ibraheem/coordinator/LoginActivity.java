package com.ibraheem.coordinator;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import api.Utils;

/**
 * Created by boro on 4/4/16.
 */
public class LoginActivity extends MainActivity {

    protected Button login ;
    protected   Button createAccount;
    protected  Button guest;
    protected EditText mUsername ;
    protected  EditText mPassword ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final Context context = this;
        guest = (Button)    findViewById(R.id.btnGuest);
        login = (Button) findViewById(R.id.btnLogin);
        createAccount =(Button) findViewById(R.id.btnCreateAccountLogin);
        mUsername = (EditText) findViewById(R.id.usernameLoginTextBox);
        mPassword = (EditText) findViewById(R.id.PasswordLoginTextBox);


        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //take user to Register
                Intent goToRegister = new Intent(LoginActivity.this , RegisterActivity.class);
                startActivity(goToRegister);
            }

        });
        guest.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                //take user to Register
                Intent goToGuest = new Intent(LoginActivity.this, GuestActivity.class);
                startActivity(goToGuest);
            }
        });

        //listen to when the Login is clicked
        // listen to creaeAccount

        login.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // get the user from the  edit text inputs and convert to string
                String username = mUsername.getText().toString().trim();
                String password = mPassword.getText().toString().trim();
                if(validate()) {
                    Utils.login(context, username, password);
                }
                else{
                    Toast.makeText(getBaseContext(), "Login failed", Toast.LENGTH_LONG).show();

                    login.setEnabled(true);
                }
            }


        });


    }

    public boolean validate() {
        boolean valid = true;

      //  String email = mUsername.getText().toString();
        String password = mPassword.getText().toString();
/*
        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            mUsername.setError("enter a valid email address");
            valid = false;
        } else {
            mUsername.setError(null);
        }
*/
        if (password.isEmpty() || password.length() < 4 || password.length() > 10) {
            mPassword.setError("between 4 and 10 alphanumeric characters");
            valid = false;
        } else {
            mPassword.setError(null);
        }

        return valid;
    }


}
