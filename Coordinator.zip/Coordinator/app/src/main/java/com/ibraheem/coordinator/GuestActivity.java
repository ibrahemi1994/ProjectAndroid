package com.ibraheem.coordinator;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

/**
 * Created by boro on 4/4/16.
 */
public class GuestActivity extends MainActivity {

    protected Button Enter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest);
        final Context context = this;
        final LayoutInflater inflater = getLayoutInflater();
        Enter = (Button) findViewById(R.id.btnGuestEnter);
        final EditText editText = (EditText) findViewById(R.id.editText);

        View layout = findViewById(R.id.jawad);
     //   ListView listView = (ListView) layout.findViewById(R.id.itemsListView);
        final ListView list = (ListView) findViewById(R.id.itemsListView2);
        Enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //take user to Register
                Intent intent = new Intent(context,homepageGuest.class);
                intent.putExtra("username", editText.getText().toString());
                startActivity(intent);
            }

        });

    }
}