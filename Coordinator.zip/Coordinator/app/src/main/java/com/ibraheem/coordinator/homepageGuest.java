package com.ibraheem.coordinator;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by boro on 4/4/16.
 */
public class homepageGuest extends MainActivity {
    private List<Item> myItems= new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepageguest);

        read();

//        populateItemList();
//        populateListView();



    }

    private void read() {
        ListView list = (ListView) findViewById(R.id.itemsListView);
        String username = getIntent().getStringExtra("username");
        api.Utils.getItem(list, getLayoutInflater(), this, username);

    }

    private void populateItemList(){
        myItems.add(new Item("item", 1, 0, "FUCK IT"));
        myItems.add(new Item("item", 1, 0, "FUCK IT"));

        myItems.add(new Item("item", 1, 0, "FUCK IT"));
        myItems.add(new Item("item", 1, 0, "FUCK IT"));
        myItems.add(new Item("item", 1, 0, "FUCK IT"));




    }
    private void populateListView(){
        ArrayAdapter<Item> adapter = new MyListAdapter();
        ListView list = (ListView) findViewById(R.id.itemsListView);
        list.setAdapter(adapter);
    }
    private class MyListAdapter extends ArrayAdapter{
     public  MyListAdapter(){
         super(homepageGuest.this ,R.layout.item_view , myItems);

     }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View itemView = convertView;
            if(itemView==null){
                itemView = getLayoutInflater().inflate(R.layout.item_view , parent, false);

            }
            // find the item to work with
            Item currItem = myItems.get(position);


            // FILL the view
           ImageView imageView = (ImageView)itemView.findViewById(R.id.item_icon);
          //  imageView.setImageResource(currItem.getId());



            // Make:
            TextView makeText = (TextView) itemView.findViewById(R.id.item_name);
            makeText.setText(currItem.getName());

            // Make:
            TextView makeDes = (TextView) itemView.findViewById(R.id.item_desc);
            makeDes.setText(currItem.getDescription());

            return  itemView;

        }
    }

}
