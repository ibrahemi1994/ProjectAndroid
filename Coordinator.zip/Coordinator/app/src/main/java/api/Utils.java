package api;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.ibraheem.coordinator.LoginActivity;
import com.ibraheem.coordinator.R;
import com.ibraheem.coordinator.eventsAdapter;
import com.ibraheem.coordinator.homepageGuest;
import com.ibraheem.coordinator.homepageUser;

import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import api.parser.Item;
import api.parser.arrayItems;
import api.parser.signup;

/**
 * Created by boro on 4/5/16.
 */
public class Utils {

    public static void register(final Context context, final String user, final String pass, final String email) {
        new AsyncTask<Void, Void, signup>() {
            @Override
            protected signup doInBackground(Void... params) {
                URL url= null;

                try {
                    url = new URL("https://collegeserver1.herokuapp.com/boro/insertuser");
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setDoOutput(true);
                    urlConnection.setRequestMethod("POST");

                    String urlParams = String.format("username=%s&password=%s&mail=%s",user,pass,email);
                    DataOutputStream out = new DataOutputStream(urlConnection.getOutputStream());
                    out.writeBytes(urlParams);
                    out.flush();
                    out.close();
                    InputStream in = urlConnection.getInputStream();
                    InputStreamReader streamReader = new InputStreamReader(in);

                    Gson gson = new Gson();
                    signup exist = gson.fromJson(streamReader,signup.class);

                    return exist;

                } catch (Exception e) {
                    e.printStackTrace();
                }

                return null;
            }

            @Override
            protected void onPostExecute(signup signup) {
                   if( signup.getSuccess() ){
                       Intent intent = new Intent (context, LoginActivity.class);
                       context.startActivity(intent);
                   }else
                       Toast.makeText(context, "Failed , Please try again", Toast.LENGTH_SHORT).show();
            }
        }.execute();


    }

    public static void login(final Context context, final String username, final String password) {
        new AsyncTask<Void, Void, signup>() {
            @Override
            protected signup doInBackground(Void... params) {
                URL url = null;

                try {
                    url = new URL("https://collegeserver1.herokuapp.com/boro/login");
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setDoOutput(true);
                    urlConnection.setRequestMethod("POST");

                    String urlParams = String.format("username=%s&password=%s", username, password);
                    DataOutputStream out = new DataOutputStream(urlConnection.getOutputStream());
                    out.writeBytes(urlParams);
                    out.flush();
                    out.close();
                    InputStream in = urlConnection.getInputStream();
                    InputStreamReader streamReader = new InputStreamReader(in);

                    Gson gson = new Gson();
                    signup exist = gson.fromJson(streamReader, signup.class);

                    return exist;

                } catch (Exception e) {
                    e.printStackTrace();
                }

                return null;
            }

            @Override
            protected void onPostExecute(signup signup) {

                if(signup.getSuccess()){
                    Intent goTouserHomePage = new Intent(context, homepageUser.class);
                    goTouserHomePage.putExtra("user",username);
                    context.startActivity(goTouserHomePage);
                }
                else
                    Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
            }
        }.execute();
    }

    public static void getItem(final ListView list, final LayoutInflater inflater, final Context context, final String username) {
        new AsyncTask<Void, Void, ArrayList<Item>>() {
            @Override
            protected ArrayList<Item> doInBackground(Void... params) {
                URL url = null;

                try {
                    url = new URL("https://collegeserver1.herokuapp.com/boro/itembyuser");
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setDoOutput(true);
                    urlConnection.setRequestMethod("POST");

                    String urlParams = String.format("username=%s",username);
                    DataOutputStream out = new DataOutputStream(urlConnection.getOutputStream());
                    out.writeBytes(urlParams);
                    out.flush();
                    out.close();
                    InputStream in = urlConnection.getInputStream();



                    InputStreamReader streamReader = new InputStreamReader(in);
                    Gson gson = new Gson();
                    arrayItems items = gson.fromJson(streamReader,arrayItems.class);
                    return (ArrayList<Item>) items.getItems();
                }
                catch (Exception e){
                    e.printStackTrace();
                }


                    return null;
            }

            @Override

            protected void onPostExecute(final ArrayList<Item> items) {
                if(items ==null || items.size() ==0)
                {
                    Toast.makeText(context, "All bought", Toast.LENGTH_SHORT).show();
                    return;
                }
             //   homepageGuest.MyListAdapter adapter = new homepageGuest.MyListAdapter(context,items);
                eventsAdapter adapter = new eventsAdapter(context,R.layout.item_view,items);
                adapter.setLayoutInflater(inflater);
                list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        final Item item = items.get(position);

                        new AsyncTask<Void, Void, Boolean>() {
                            @Override
                            protected Boolean doInBackground(Void... params) {
                                URL url = null;

                                try {
                                    url = new URL("https://collegeserver1.herokuapp.com/boro/removeitem");
                                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                                    urlConnection.setDoOutput(true);
                                    urlConnection.setRequestMethod("POST");

                                    String urlParams = String.format("id=%d", item.getId());
                                    DataOutputStream out = new DataOutputStream(urlConnection.getOutputStream());
                                    out.writeBytes(urlParams);
                                    out.flush();
                                    out.close();
                                    InputStream in = urlConnection.getInputStream();


                                    InputStreamReader streamReader = new InputStreamReader(in);
                                    Gson gson = new Gson();
                                    signup items = gson.fromJson(streamReader, signup.class);
                                    return items.getSuccess();
                                }
                                catch (Exception e){
                                    e.printStackTrace();
                                }

                                return null;
                            }

                            @Override
                            protected void onPostExecute(Boolean aVoid) {
                                Intent intent = new Intent(context,homepageGuest.class);
                                intent.putExtra("username",username);
                                context.startActivity(intent);
                            }
                        }.execute();
                    }
                });

                list.setAdapter(adapter);

            }

        }.execute();

    }

    public static void getItemforuser(final Context context, final ListView list, final LayoutInflater layoutInflater, homepageUser homepageUser, final String username) {
        new AsyncTask<Void, Void, ArrayList<Item>>() {
            @Override
            protected ArrayList<Item> doInBackground(Void... params) {
                URL url = null;

                try {
                    url = new URL("https://collegeserver1.herokuapp.com/boro/update");
                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setDoOutput(true);
                    urlConnection.setRequestMethod("POST");

                    String urlParams = String.format("username=%s", username);
                    DataOutputStream out = new DataOutputStream(urlConnection.getOutputStream());
                    out.writeBytes(urlParams);
                    out.flush();
                    out.close();
                    InputStream in = urlConnection.getInputStream();


                    InputStreamReader streamReader = new InputStreamReader(in);
                    Gson gson = new Gson();
                    arrayItems items = gson.fromJson(streamReader, arrayItems.class);
                    return (ArrayList<Item>) items.getItems();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(final ArrayList<Item> items) {
                if(items ==null || items.size() ==0)
                {
                    Toast.makeText(context, "Empty List", Toast.LENGTH_SHORT).show();
                    return;
                }
                //   homepageGuest.MyListAdapter adapter = new homepageGuest.MyListAdapter(context,items);
                eventsAdapter adapter = new eventsAdapter(context,R.layout.item_view,items);
                adapter.setLayoutInflater(layoutInflater);
                list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        final Item item = items.get(position);
                        Toast.makeText(context, "Item Added", Toast.LENGTH_SHORT).show();
                        new AsyncTask<Void, Void, Boolean>() {
                            @Override
                            protected Boolean doInBackground(Void... params) {
                                URL url = null;

                                try {
                                    url = new URL("https://collegeserver1.herokuapp.com/boro/insertItem");
                                    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                                    urlConnection.setDoOutput(true);
                                    urlConnection.setRequestMethod("POST");

                                    String urlParams = String.format("username=%s&name=%s&description=%s&image=%s",username,item.getName(),item.getDescription(),item.getImage());
                                    DataOutputStream out = new DataOutputStream(urlConnection.getOutputStream());
                                    out.writeBytes(urlParams);
                                    out.flush();
                                    out.close();
                                    InputStream in = urlConnection.getInputStream();


                                    InputStreamReader streamReader = new InputStreamReader(in);
                                    Gson gson = new Gson();
                                    signup items = gson.fromJson(streamReader, signup.class);
                                    return items.getSuccess();
                                }
                                catch (Exception e){
                                    e.printStackTrace();
                                }

                                return null;
                            }

                        }.execute();
                    }
                });

                list.setAdapter(adapter);

            }
        }.execute();
    }
}
